import { Form } from './Form';

const Signin = () => {
  return (
    <>
      <h2>Inicio de sesion</h2>
      <Form />
    </>
  );
};

export default Signin;
